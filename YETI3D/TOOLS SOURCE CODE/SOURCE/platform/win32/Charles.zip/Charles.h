
#ifndef __CHARLES_H__
#define __CHARLES_H__

#ifdef  __cplusplus
extern "C" {
#endif

#include "DibHelp.h"
#include "DibPal.h"
#include "DibConv.h"
#include "EZFont.h"

#ifdef  __cplusplus
};
#endif

#endif

