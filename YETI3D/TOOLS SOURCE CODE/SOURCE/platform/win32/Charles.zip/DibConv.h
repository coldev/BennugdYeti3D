/*-------------------------------------
   DIBCONV.H header file for DIBCONV.C
  -------------------------------------*/

HDIB DibConvert (HDIB hdibSrc, int iBitCountDst) ;
